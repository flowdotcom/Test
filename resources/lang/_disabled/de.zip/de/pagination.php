<?php
return [
    'previous' => '&laquo; Zurück',
    'next'     => 'Weiter &raquo;'
];